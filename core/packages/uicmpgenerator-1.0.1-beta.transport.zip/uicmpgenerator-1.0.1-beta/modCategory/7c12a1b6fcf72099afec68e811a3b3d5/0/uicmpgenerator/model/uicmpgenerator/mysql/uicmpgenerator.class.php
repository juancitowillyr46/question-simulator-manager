<?php
require_once (dirname(dirname(__FILE__)) . '/uicmpgenerator.class.php');
class Uicmpgenerator_mysql extends Uicmpgenerator {}