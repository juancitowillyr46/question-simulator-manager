<?php
class Uicmpgenerator extends xPDOSimpleObject {}