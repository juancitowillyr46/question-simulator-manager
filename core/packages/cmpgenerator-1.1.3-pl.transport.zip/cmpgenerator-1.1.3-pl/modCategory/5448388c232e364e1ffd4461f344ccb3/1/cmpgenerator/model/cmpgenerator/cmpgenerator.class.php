<?php
class CmpGenerator extends xPDOSimpleObject {}