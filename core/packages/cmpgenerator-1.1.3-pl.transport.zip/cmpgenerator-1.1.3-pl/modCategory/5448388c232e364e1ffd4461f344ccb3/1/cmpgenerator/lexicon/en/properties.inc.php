<?php
/**
 * @package doodles
 * @subpackage lexicon
 */
$_lang['prop_socialstream.ascending'] = 'Ascending';
$_lang['prop_socialstream.descending'] = 'Descending';
$_lang['prop_socialstream.dir_desc'] = 'The direction to sort by.';
$_lang['prop_socialstream.sort_desc'] = 'The field to sort by.';
$_lang['prop_socialstream.tpl_desc'] = 'The chunk for displaying each row.';